import React from 'react'
import './Homework.css'

const Homework = () => {
  return (
    <div className="box">
      <h1>TODO LIST</h1>
      <hr />

      <div className='txtbox'>
        <input className='txtbox-txt' type="text" placeholder='add item...' /> <br />
        <button className='hbtn' type='submit'>Add</button>
      </div>

      <div className='testbox'>
        
      <div className='testbox-box'>
        <p>Task1</p>
          <div className='testbox-btn'>
            <button>Delete</button>
            <button>Edit</button>
          </div>
        </div> 

        <div className='testbox-box'>
        <p>Task2</p>
        <div className='testbox-btn'>
            <button>Delete</button>
            <button>Edit</button>
          </div>
        </div> 

        <div className='testbox-box'>
        <p>Task3</p>
    
        <div className='testbox-btn'>
            <button>Delete</button>
            <button>Edit</button>
          </div>
        </div> 
      </div>
    </div>
  )
}

export default Homework